//---   Imports   ---//
require('colors');

//---   Start Lab Link   ---//
require('./handlers/start')();
require('./handlers/scpsl').start();