const fs = require('fs');
const config = require('../config');
module.exports = (data) => {
    fs.watch()
}